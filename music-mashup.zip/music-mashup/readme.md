## Music mashup
This is a proof of concept app, built for Cygni as a programming test

## Requirements
Node >= 12.9
NPM

## Setup
```bash
npm install
npm start
```