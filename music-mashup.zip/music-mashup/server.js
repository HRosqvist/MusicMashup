const express = require('express')
const musicbrainz = require('./src/musicbrainz')
const wikidata = require('./src/wikidata')
const wikipedia = require('./src/wikipedia')
const coverart = require('./src/coverartarchive')
const app = express()
const port = 3000

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/src/index.html')
})

app.get('/mbid/:mbid', (req, res) => {
    const mbid = req.params.mbid
    let musicbrainzData
    let wikiDataIdentifier
    let description

    let musicbrainzPromise = musicbrainz.getMusicbrainzData(mbid)
    musicbrainzPromise.then(data => {
        if (!data.error) {
            musicbrainzData = data
            wikiDataIdentifier = musicbrainzData.relations.find(relation => relation.type === 'wikidata')

            return wikidata.getWikipediaLink(wikiDataIdentifier)
        } else {
            res.send('Invalid mbid')
        }   
    })
    .then(bandName => {
        return wikipedia.getWikiDescription(bandName)
    })
    .then(data => {
        description = data
        
        return coverart.loadAlbumImages(musicbrainzData['release-groups'])
    })
    .then(albumImage => {
        let response = {
            mbid: mbid,
            description: description,
            albums: albumImage,
        }

        res.send(response)
    })
    .catch(error => {
        console.error(error)
        res.send('Error getting data')
    })
})

app.listen(port, () => console.log('Listening on port ' + port))