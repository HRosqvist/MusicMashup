//This module returns an array of image links to cover art of a given artists albums
const fetch = require('cross-fetch')
const coverartarchiveURL = 'http://coverartarchive.org/release-group/'

function getAlbumImage(albumId, title) {
    return new Promise((resolve, reject) => {
        fetch(coverartarchiveURL + albumId)
        .then(response => response.json())
        .then((data) => {
            let album = {
                title: title,
                id: albumId,
                image: data.images[0].image, 
            }

            resolve(album)
        })
        .catch(error => {
            let album = {
                title: title,
                id: albumId,
                image: 'Image not found',
            }

            resolve(album)
        })
    })
}

async function loadAlbumImages(releaseGroup) {
    let requests = []
    let coverImages = []

    releaseGroup.forEach(
        (album) => {
            requests.push(getAlbumImage(album.id, album.title))
        })

    await Promise.allSettled(requests)
    .then(data => {
        data.forEach(
            (cover) => {
                coverImages.push(cover.value)
            }
        )
    })

    return coverImages
}

module.exports = {
    loadAlbumImages,
}