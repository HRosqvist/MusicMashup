//This module fetches data from the musicbrainz api with a given id
const fetch = require('cross-fetch')
const musicbrainzURL = 'http://musicbrainz.org/ws/2/artist/'
const musicbrainzEnd = '?&fmt=json&inc=url-rels+release-groups'

async function getMusicbrainzData(mbid) {
    return new Promise((resolve, reject) => {
        fetch(musicbrainzURL + mbid + musicbrainzEnd)
        .then(response => response.json())
        .then(data => {
            resolve(data)
        })
        .catch(error => {
            resolve('Invalid mbid')
        })
    })
}

module.exports = {
    getMusicbrainzData,
}
