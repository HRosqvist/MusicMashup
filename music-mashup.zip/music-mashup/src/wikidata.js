//This module fetches the wikipedia title of a supplied wikidata entry
const fetch = require('cross-fetch')
const wikiDataURL = 'https://www.wikidata.org/w/api.php?action=wbgetentities&ids='
const wikiDataEnd = '&format=json&props=sitelinks'

async function getWikipediaLink(wikiDataIdentifier) {
    if (wikiDataIdentifier) {
        wikiDataIdentifier = wikiDataIdentifier.url.resource.substring(wikiDataIdentifier.url.resource.lastIndexOf('/') + 1)
    } else {
        return 'No wikidata available'
    }

    return new Promise((resolve, reject) => {
        fetch(wikiDataURL + wikiDataIdentifier + wikiDataEnd)
        .then(response => response.json())
        .then(data => {
            let wikipediaName = data.entities[wikiDataIdentifier].sitelinks.enwiki.title
            resolve(wikipediaName)
        })
        .catch(error => {
            resolve('Unable to get link to wikipedia')
        })
    })
}

module.exports = {
    getWikipediaLink,
}