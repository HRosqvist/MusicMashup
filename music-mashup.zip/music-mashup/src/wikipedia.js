//This module returns the extract of a wikipedia article
const fetch = require('cross-fetch')
const wikipediaURL = 'https://en.wikipedia.org/w/api.php?action=query&format=json&prop=extracts&exintro=true&redirects=true&titles='

async function getWikiDescription(bandName) {
    let encodedBandName = encodeURIComponent(bandName)
    return new Promise((resolve, reject) => {
        fetch(wikipediaURL + encodedBandName)
        .then(response => response.json())
        .then(data => {
            let description = data.query.pages[Object.keys(data.query.pages)[0]].extract

            if (!description)
                description = 'No wikipedia article found for artist'

            resolve(description)
        })
        .catch(error => {
            resolve('Could not get description for this artist')
        })
    })
}

module.exports = {
    getWikiDescription,
}